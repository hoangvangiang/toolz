module.exports = {
	printWidth: 80,
	bracketSpacing: true,
	semi: false,
	singleQuote: true,
	tabWidth: 4,
	trailingComma: 'none',
	useTabs: true
}
