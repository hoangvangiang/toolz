const s_test_pagead = true
console.log('s_test_pageads : ', s_test_pagead)
