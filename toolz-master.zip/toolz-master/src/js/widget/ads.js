var s_test_ads = 's_test_ads'
console.log('Hey there ..... check out ', 'https://youtu.be/dQw4w9WgXcQ')

var e = document.createElement('div')
e.id = 'ECKckuBYwZaP'
e.style.display = 'none'
document.body.appendChild(e)
