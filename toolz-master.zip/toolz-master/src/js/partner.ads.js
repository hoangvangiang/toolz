var s_test_partnerads = 'https://youtu.be/dQw4w9WgXcQ'
console.log('s_test_partnerads : ', s_test_partnerads)
