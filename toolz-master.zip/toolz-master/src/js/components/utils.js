//Copy to clipboard the str value
